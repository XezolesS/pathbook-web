## 개발환경구축
 1. Github Repoisitory 생성
 2. VSCode Repoisitory 불러오기
 3. 가상환경 생성
  conda create -n llm python=3.11
  conda env list
  conda activate llm
 4. VSCode와 가상환경 연결
  Vs확장 설치
  Python, Python Extended, Python Extension Pack