import os
from dotenv import load_dotenv, find_dotenv
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import PyPDFLoader
from langchain_community.vectorstores import FAISS
from langchain_openai import OpenAIEmbeddings
from langchain_openai import ChatOpenAI
from langgraph.graph import StateGraph, END
from typing_extensions import TypedDict
from langchain.prompts import ChatPromptTemplate
from langchain.chains.combine_documents import create_stuff_documents_chain
from langchain.chains.retrieval import create_retrieval_chain

# 1. 환경 변수 로딩 및 LLM 설정
_ = load_dotenv(find_dotenv())
openai_api_key = os.getenv("OPENAI_API_KEY")
llm = ChatOpenAI(model="gpt-4", temperature=0.1, api_key=openai_api_key)

# 2. LangGraph 상태 정의
class RAGState(TypedDict):
    question: str
    answer: str
    search_source: str

# 3. PDF 문서 로딩 및 벡터스토어 구성
def load_and_index_pdf(pdf_path: str):
    loader = PyPDFLoader(pdf_path)
    documents = loader.load()
    
    # chunk_size: 키우면 하나의 청크에 상대적으로 많은 텍스트가 들어가므로, 문맥이 깨지지 않고 관련 정보가 한 덩어리로 잘 묶임
    # chunk_overlap: 청크 사이에 일부 텍스트가 겹치게 되어, 청크 경게에서 문맥이 끊기는 현상을 줄이고 정보 유실 최소화(앞뒤맥락유지)
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=800,      # 기본보다 큼
        chunk_overlap=150,   # 문맥 유지
        separators=["\n\n", "\n", ".", " ", ""]
    )
    texts = text_splitter.split_documents(documents)

    embeddings = OpenAIEmbeddings(api_key=openai_api_key)
    vectorstore = FAISS.from_documents(texts, embeddings)
    return vectorstore

# 4. LangGraph 노드: 질의 처리 (RAG 실행)
def rag_node(state: RAGState):
    question = state["question"]
    
    # 디폴트: search_type="similarity", K=4  -> 가장 유사한 문서 4개 반환하는 검색기
    retriever = vectorstore.as_retriever()
    
    # retriever 성능향상
    #  - MMR(Maximum Marginal Relevance, 최대 한계 관련성) 알고리즘으로 문서 검색 -> 쿼리와 유사성뿐만 아니라 이미 선택된 문서들과의 중복성 최소화(결과의 다양성 향상)
    # retriever = vectorstore.as_retriever(search_type="mmr", search_kwargs={"k": 5})

    # system prompt 정의
    system_prompt = """
        당신은 지식검색시스템입니다.
        다음 질문에 대해 제공된 문서를 바탕으로 정확하고 간결하게 한국어로 답변하세요.
        제공된 문서 이외의 내용은 "답변이 어렵습니다."라고 답하세요.

        문서 내용:
        {context}
    """
    
    # 프롬프트 구성: context는 문서, input은 질문
    prompt = ChatPromptTemplate.from_messages(
        [
            ("system", system_prompt + "\n\n문서 내용:\n{context}"),
            ("human", "{input}"),
        ]
    )
    
    # 문서 결합 체인 생성
    document_chain = create_stuff_documents_chain(llm=llm, prompt=prompt)
    
    # RAG 체인 구성
    #  - create_retrieval_chain은 context에 검색된 문서 자동 저장
    #  - 따라서, return_source_documents=True 사용하지 않아도 됨
    rag_chain = create_retrieval_chain(
        retriever=retriever, 
        combine_docs_chain=document_chain,
    )
    
    # RAG 실행 (질문을 'input' 키로 전달)
    result = rag_chain.invoke({"input": question}) 
    
    # 검색된 문서 일부 출력 (콘솔)
    print("\n검색된 문서 내용:")
    for i, doc in enumerate(result["context"], 1):
        print(f"\n--- 문서 {i} ---")
        print(doc.page_content[:500])
        
    # LangGraph 상태로 반환
    return {"question": question, "answer": result["answer"], "search_source": result["context"]}

# 5. LangGraph 그래프 정의
def build_graph():
    graph = StateGraph(RAGState)
    graph.add_node("rag", rag_node)
    graph.set_entry_point("rag")
    graph.set_finish_point("rag")
    return graph.compile()

# 6. 메인 실행부
if __name__ == "__main__":
    # PDF 파일 경로
    pdf_path = "assets/info.pdf"  # 원하는 PDF 파일명으로 변경
    
    # 문서 인덱싱 및 그래프 실행
    vectorstore = load_and_index_pdf(pdf_path)
    app = build_graph()
    
    # 사용자 질문 입력
    user_input = input("질문을 입력하세요: ")
    
    # 그래프 실행
    result = app.invoke({"question": user_input})
    
    # 답변 출력
    print("답변:", result["answer"])