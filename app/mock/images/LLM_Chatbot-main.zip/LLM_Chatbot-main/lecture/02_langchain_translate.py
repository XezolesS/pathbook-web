from langchain_openai import ChatOpenAI
from dotenv import load_dotenv, find_dotenv
import os
from langchain.prompts import ChatPromptTemplate

_ = load_dotenv(find_dotenv())

llm = ChatOpenAI(
    model="gpt-4o-mini",
    api_key=os.getenv("OPENAI_API_KEY"),
    temperature=0
)

system_prompt ="""
   너는 소설을 쓰는 작가를 보조하는 역할이에요.
   전달받은 글을 다음 조건에 맞게 한국어에서 '{lang}'로 번역해주세요.
   
   조건1. 작가의 질문에 절대로 답변하지 마세요.
   조건2. 작가의 글을 문자열 그대로 번역해주세요.
   조건3. 문법에 신경써서 번역해주세요.
   조건4. 줄임말과 신조어 등은 최대한 사용하지마세요.
   조건5. 판타지 소설에서 많이 사용하는 문체와 어조로 번역해주세요.
   조건6. 번역시 기존 글의 스타일을 유지해주세요.
"""

prompt = ChatPromptTemplate.from_messages([
    ("system", system_prompt),
    ("human", "{novel}")
])

novel="""
    깊은 안개가 드리운 에라니아 숲속, 전설로만 전해지던 청룡의 숨결이 다시 깨어났다.
    평범한 사서였던 라일라는, 어느 날 낡은 책장에서 빛나는 고대의 서책을 발견한다.
    서책을 펼친 순간, 그녀의 손목에 붉은 룬 문양이 새겨지고 눈앞에 낯선 문이 열렸다.
    그 문 너머엔 말을 하는 늑대와, 하늘을 나는 섬들이 떠 있는 세계가 기다리고 있었다.
    "운명의 조율자시군요," 늑대는 말했다. "우리 세계의 균형이 무너졌습니다."
    라일라는 믿기지 않았지만, 자신의 꿈에서 그 섬들을 이미 본 적이 있었다.
    마법사들과 검객, 그리고 배신자들이 얽힌 고대의 예언이 그녀의 손에 달려 있었다.
    그녀는 결심했다. 현실로 돌아갈 길은 잊고, 이 세계를 구하기 위한 여정을 시작하겠다고.
    첫 번째 시험은 불의 정령이 지키는 산맥을 넘어야 하는 것이었다.
    라일라의 눈동자에는 두려움보다도 강한 빛, 바로 운명을 바꿀 자의 의지가 담겨 있었다.
"""

lang = "영어"

novel_input = {
    "novel" : novel,
    "lang" : lang
}

chain = prompt | llm
result = chain.invoke(novel_input)
print(result.content)