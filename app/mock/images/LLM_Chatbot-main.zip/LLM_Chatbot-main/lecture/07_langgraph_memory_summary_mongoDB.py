import uuid
import os
from typing import Annotated
from pymongo import MongoClient
from langchain_openai import ChatOpenAI
from typing_extensions import TypedDict
from langchain_core.messages import HumanMessage, SystemMessage, RemoveMessage, AIMessage
from langgraph.graph.message import add_messages
from langchain_core.runnables import RunnableConfig
from langgraph.graph import START, END, StateGraph
from dotenv import load_dotenv, find_dotenv
from langgraph.checkpoint.memory import MemorySaver


_ = load_dotenv(find_dotenv())
model = ChatOpenAI(
            api_key = os.getenv("OPENAI_API_KEY"),
            temperature=0.0,
            model="gpt-4o-mini"
        )
memory = MemorySaver()
MONGO_URI = os.getenv("MONGODB_URI", "mongodb://localhost:27017")
mongo_client = MongoClient(
    host=MONGO_URI,
    port=27017,
    username="admin",
    password="secret",
    authSource="admin",
    serverSelectionTimeoutMS=5000)
db = mongo_client["db_chat"]
conversations = db["conversations"]

thread_id = str(uuid.uuid4())
config = RunnableConfig(
    recursion_limit=10,  
    configurable={"thread_id": thread_id}  
)

# 세션 문서 초기화(없으면 생성)
conversations.update_one(
    {"session_id": thread_id},
    {"$set": {"session_id": thread_id, "messages": []}},
    upsert=True
)

class State(TypedDict):
    query: str  # 최신 사용자 질문
    messages: Annotated[list, add_messages]  # 대화 기록
    summary: str   # 대화 기록 요약


def ask_llm(state: State):

    human = HumanMessage(content=state["query"])
    summary = state.get("summary", "")
    if summary:
        system_message = f"Summary of conversation earlier: {summary}"
        messages = [SystemMessage(content=system_message)] + state["messages"] + [human]
    else:
        messages = state["messages"] + [human]
        
    response = model.invoke(messages)
    return {
        "query": state["query"],  # 현재 질문
        "messages": [human, response]    # 이전 기록 유지한채로, response 메시지만 추가
    }

def should_continue(state: State):
    messages = state["messages"]
    if len(messages) > 4:
        return "summarize_conversation"
    return END


def summarize_conversation(state: State):
    pairs = []
    msgs = state["messages"]
    for i in range(0, len(msgs), 2):
        q = msgs[i]
        a = msgs[i+1] if i+1 < len(msgs) else None
        if isinstance(q, HumanMessage) and isinstance(a, AIMessage):
            pairs.append((q.content, a.content))

    # 2) 요약용 프롬프트 조립
    #    — 질문은 그대로, 답변만 한두 문장으로 요약해 달라는 지시를 포함
    prompt_lines = []
    for idx, (q_text, a_text) in enumerate(pairs, start=1):
        prompt_lines.append(f"질문{idx}: {q_text}")
        prompt_lines.append(f"답변{idx}: {a_text}")
    prompt_body = "\n".join(prompt_lines)
    instruction = (
        "\n\n위 대화에서 질문은 그대로 두고, "
        "각 질문에 대응하는 ‘답변’만 한두 문장으로 요약하여 "
        "아래 형식으로 작성해주세요:\n\n"
        "질문: …\n"
        "답변: …\n"
        "질문: …\n"
        "답변: …\n"
        "…"
    )
    full_prompt = prompt_body + instruction

    old_summary = state.get("summary", "").strip()

    # 3) 요약 요청
    response = model.invoke([HumanMessage(content=full_prompt)])
    new_summary = response.content.strip()
    # 4) 원래 메시지 전부 삭제(RemoveMessage) → 요약만 남김
    delete_messages = [RemoveMessage(id=m.id) for m in msgs]

    if old_summary:
        combined_summary = f"{old_summary}\n\n{new_summary}"
    else:
        combined_summary = new_summary
    return {
        "summary": combined_summary,
        "messages": delete_messages
    }


def build_graph(checkpointer):
    workflow = StateGraph(state_schema=State)
    workflow.add_node("conversation", ask_llm)
    workflow.add_node(summarize_conversation)
    workflow.add_edge(START, "conversation")
    workflow.add_conditional_edges(
        "conversation",
        should_continue
    )
    workflow.add_edge("summarize_conversation", END)
    return workflow.compile(checkpointer=checkpointer)



def print_and_persist(update):
    # 업데이트 딕셔너리 순회
    for _, v in update.items():
        for m in v["messages"]:
            m.pretty_print()  # 화면에 출력
            
            if isinstance(m, RemoveMessage):
                continue
            if isinstance(m, HumanMessage):
                continue
            conversations.update_one(
                {"session_id": thread_id},
                {"$push": {
                    "messages": {
                        "role": getattr(m, "role", "assistant"),
                        "content": m.content,
                        "id": m.id
                    }
                }},
                upsert=True
            )
        # 대화 내용 저장장
        if "summary" in v:
            print("\n[New summary]\n", v["summary"], "\n")
            conversations.update_one(
                {"session_id": thread_id},
                {"$set": {"summary": v["summary"]}}
            )


print(f"Your session ID: {thread_id}\n")
while True:
    query = input("Prompt: ").strip()
    if query == "exit":
        break
    human_msg = HumanMessage(content=query)
    
    conversations.update_one(
        {"session_id": thread_id},
        {"$push": {
            "messages": {
                "role": "user",
                "content": query,
                "id": human_msg.id  # 향후 계정 ID로 대체
            }
        }}
    )
    
    graph = build_graph(memory)
    for event in graph.stream({"query": query}, config=config, stream_mode="updates"):
        print_and_persist(event)