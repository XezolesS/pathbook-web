from langchain_openai import ChatOpenAI
from dotenv import load_dotenv, find_dotenv
import os
from langchain.prompts import ChatPromptTemplate

_ = load_dotenv(find_dotenv())

llm = ChatOpenAI(
    model="gpt-4o-mini",
    api_key=os.getenv("OPENAI_API_KEY"),
    temperature=0,
    )

system_prompt = """
    You are a helpful assistant.
    You will be provided with a set of documents and a question.
"""

prompt = ChatPromptTemplate.from_messages([
    ("system",system_prompt),
    ("human","{question}")
])

chain = prompt | llm
question = "나의 이름은 김찬희야"
result = chain.invoke({"question": question})

print(result.content)